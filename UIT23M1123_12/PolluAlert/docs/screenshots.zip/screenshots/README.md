# PolluAlert screenshots

Ten distinct, unedited screenshots captured from the running project on 2 October 2026. Each image is 1280 x 720 pixels and shows only the app viewport.

Open [the gallery](index.html) to browse all images, or open any JPEG directly.

The six sample incidents were submitted through the actual UI into `data/demo_reports.db`. The normal report database was preserved. Use `run_demo.ps1` from the project root to reopen the demo.

1. [Home](01_home.jpg) - Project introduction and supported pollution categories.
2. [Analysis form](02_analysis_form.jpg) - Input form with quick examples and the Analyze Incident button.
3. [Air pollution](03_air_pollution.jpg) - Factory smoke example with Mumbai location extraction.
4. [Water pollution](04_water_pollution.jpg) - River contamination example with medium severity.
5. [Noise pollution](05_noise_pollution.jpg) - Late-night loud music example.
6. [Waste / garbage pollution](06_waste_pollution.jpg) - Garbage dumped near a school.
7. [Chemical emergency](07_chemical_emergency.jpg) - Chemical leak and breathing-problem example.
8. [Normal observation](08_normal_observation.jpg) - Sunny weather example classified as Not Pollution.
9. [Analytics dashboard](09_analytics_dashboard.jpg) - Counts and charts from six actual demo submissions.
10. [Model performance](10_model_performance.jpg) - Evaluation method and pollution-type/severity model comparisons.
